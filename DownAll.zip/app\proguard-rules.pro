﻿-keep class com.yausername.** { *; }
-keep class com.fasterxml.jackson.** { *; }
-keep class org.apache.commons.io.** { *; }
-keep class java.util.zip.** { *; }
-keep class java.util.jar.** { *; }
-dontwarn java.beans.**
-dontwarn javax.xml.**
-dontwarn org.apache.commons.**